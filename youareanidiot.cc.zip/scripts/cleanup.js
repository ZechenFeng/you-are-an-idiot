let footer = document.querySelector('#youare-footer');

function removeFooter() {
	footer.remove()
}

container.addEventListener('click', removeFooter);